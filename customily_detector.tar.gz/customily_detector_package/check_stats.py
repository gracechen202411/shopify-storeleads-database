#!/usr/bin/env python3
import os
import psycopg2

DATABASE_URL = os.environ.get('DATABASE_URL') or os.environ.get('POSTGRES_URL_NON_POOLING')

if not DATABASE_URL:
    print("❌ DATABASE_URL not found")
    exit(1)

conn = psycopg2.connect(DATABASE_URL)
cur = conn.cursor()

# 总体统计
cur.execute('''
    SELECT 
        COUNT(*) as total_checked,
        SUM(CASE WHEN has_customily THEN 1 ELSE 0 END) as with_customily,
        SUM(CASE WHEN has_customily = false THEN 1 ELSE 0 END) as without_customily,
        MAX(customily_check_date) as last_check
    FROM stores
    WHERE customily_check_date IS NOT NULL
''')

result = cur.fetchone()
if result[0] == 0:
    print("⚠️  还没有检测数据")
    exit(0)

total, with_c, without_c, last_check = result

print("="*60)
print("📊 Customily 检测统计")
print("="*60)
print(f"总检测数: {total:,}")
print(f"安装 Customily: {with_c:,} ({with_c/total*100:.1f}%)")
print(f"未安装: {without_c:,} ({without_c/total*100:.1f}%)")
print(f"最后检测: {last_check}")
print("="*60)

# 按国家统计
cur.execute('''
    SELECT 
        country_code,
        COUNT(*) as total,
        SUM(CASE WHEN has_customily THEN 1 ELSE 0 END) as with_customily
    FROM stores
    WHERE customily_check_date IS NOT NULL
    GROUP BY country_code
    ORDER BY total DESC
    LIMIT 10
''')

print("\n按国家统计:")
for country, total, with_c in cur.fetchall():
    print(f"  {country}: {total:,} 个 (Customily: {with_c:,})")

cur.close()
conn.close()
