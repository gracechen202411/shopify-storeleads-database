#!/bin/bash

echo "=================================="
echo "🚀 Customily 检测快速启动"
echo "=================================="

# 检查环境变量
if [ -z "$DATABASE_URL" ] && [ -z "$POSTGRES_URL_NON_POOLING" ]; then
    echo ""
    echo "⚠️  环境变量未设置"
    echo "运行: source .env"
    echo ""
    exit 1
fi

echo ""
echo "选择运行模式:"
echo "1) 快速测试 - 10个店铺 (1分钟)"
echo "2) 小批量测试 - 50个店铺 (4分钟)"
echo "3) 中批量测试 - 100个店铺 (8分钟)"
echo "4) 高流量店铺 - 51,411个 (3天) ⭐推荐"
echo "5) 全部店铺 - 207,712个 (12天)"
echo "6) 后台运行 - 高流量店铺"
echo ""
read -p "请选择 (1-6): " choice

case $choice in
    1)
        echo ""
        echo "🧪 启动快速测试..."
        python3 check_customily_test10_auto.py
        ;;
    2)
        echo ""
        echo "🧪 启动小批量测试..."
        python3 check_customily_test50.py
        ;;
    3)
        echo ""
        echo "🧪 启动中批量测试..."
        python3 check_customily_test100.py
        ;;
    4)
        echo ""
        echo "🎯 启动高流量店铺检测..."
        python3 check_customily_high_traffic.py
        ;;
    5)
        echo ""
        echo "🚀 启动全部店铺检测..."
        python3 check_customily_app.py
        ;;
    6)
        echo ""
        echo "🚀 后台运行高流量店铺检测..."
        nohup python3 check_customily_high_traffic.py > customily_check.log 2>&1 &
        echo $! > customily_check.pid
        echo "✅ 已在后台启动"
        echo "查看日志: tail -f customily_check.log"
        echo "进程 ID: $(cat customily_check.pid)"
        ;;
    *)
        echo "❌ 无效选择"
        exit 1
        ;;
esac
