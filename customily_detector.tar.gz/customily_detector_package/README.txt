Customily 检测系统 - Mac mini 版本

快速开始：
1. source .env
2. ./quick_start.sh

详细说明请查看：MAC_MINI_SETUP.md
